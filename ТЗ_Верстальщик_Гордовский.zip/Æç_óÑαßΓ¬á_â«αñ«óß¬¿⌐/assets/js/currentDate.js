let dateItem = document.querySelector('.footer__text');

dateItem.innerHTML = `Copyright ${new Date().getFullYear()}`;