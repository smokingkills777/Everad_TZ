document.addEventListener( 'DOMContentLoaded', function () {
	new Splide( '.splide', {
    'type': 'loop'
  } ).mount();
} );